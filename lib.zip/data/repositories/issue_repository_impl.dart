import 'dart:convert';

import 'package:d_github_issue/core/error/exception.dart';
import 'package:d_github_issue/core/error/failures.dart';
import 'package:d_github_issue/core/network/network_info.dart';
import 'package:d_github_issue/data/datasources/issue/issue_local_data_sources.dart';
import 'package:d_github_issue/data/datasources/issue/issue_remote_data_sources.dart';
import 'package:d_github_issue/domain/entities/issues_data.dart';
import 'package:d_github_issue/domain/repositories/issue_repository.dart';
import 'package:dartz/dartz.dart';

class IssueRpositoryImpl extends IssueRepository {
  final IssueRemoteDataSource remoteDataSource;
  final IssueLocalDataSources localDataSources;
  final NetworkInfo networkInfo;
  List<GithubIssue> gitissue = [];

  @override
  Future<Either<Failure, List<GithubIssue>>> getIssue() async {
    // TODO: implement getIssue
    print("getIssue Inner Side");
    if (gitissue.isNotEmpty) {
      return Right(gitissue);
    } else if (await networkInfo.isConnected == true) {
      print("Network Connected");
      try {
        final remoteIssue = await remoteDataSource.getIssue();
        localDataSources.cacheIssue(remoteIssue);
        gitissue = remoteIssue;
        return Right(remoteIssue);
      } catch (e) {
        print(e);
        return Left(ServerFailure());
      }
    } else {
      try {
        final localIssue = await localDataSources.getIssue();
        gitissue = localIssue;
        return Right(localIssue);
      } catch (e) {
        return Left(CacheFailure());
      }
    }
  }

  IssueRpositoryImpl(
      {required this.remoteDataSource,
      required this.localDataSources,
      required this.networkInfo});
}
