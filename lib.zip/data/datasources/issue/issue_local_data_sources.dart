import 'dart:convert';

import 'package:d_github_issue/core/error/exception.dart';
import 'package:d_github_issue/domain/entities/issues_data.dart';
import 'package:shared_preferences/shared_preferences.dart';
abstract class IssueLocalDataSources{
  Future<List<GithubIssue>> getIssue();
  Future<void> cacheIssue(List<GithubIssue> movetocache);
}
const Cached_Issue='Cached_Issue';
class IssueLocalDataSourcesImpl implements IssueLocalDataSources{
  final SharedPreferences sharedPreferences;
  IssueLocalDataSourcesImpl({required this.sharedPreferences});

  @override
  Future<void> cacheIssue(List<GithubIssue> movetocache) {
    // TODO: implement cacheIssue
    return sharedPreferences.setString('Cached_Issue', json.encode(GithubIssueFromJson(movetocache.toString())));
  }

  @override
  Future<List<GithubIssue>> getIssue() async{
    // TODO: implement getIssue
    final jsonString=sharedPreferences.getString(Cached_Issue);
    if(jsonString!=null){
      return Future.value(GithubIssueFromJson(json.decode(jsonString)));
    }else{
      throw CacheException();
    }
  }
}