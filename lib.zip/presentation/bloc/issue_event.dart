import 'package:equatable/equatable.dart';

abstract class IssueEvent extends Equatable{}