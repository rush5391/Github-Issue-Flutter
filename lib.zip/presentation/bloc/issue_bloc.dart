import 'dart:convert';
import 'dart:developer' as logger;
import 'package:d_github_issue/core/error/failures.dart';
import 'package:d_github_issue/domain/entities/issues_data.dart';
import 'package:d_github_issue/domain/usecases/get_issue.dart';
import 'package:d_github_issue/presentation/bloc/issue_event.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:d_github_issue/presentation/bloc/issue_state.dart';

class IssueBloc extends Cubit<IssueState> {
  final GetIssue githubIssue;

  IssueBloc({required this.githubIssue}) :assert(githubIssue!=null), super(IssueInitial());

  Future<void> getI() async {
    emit(IssueLoading());
    logger.log('1.2.1');
    final getIsue = await githubIssue.repository.getIssue();
    getIsue.fold(
        (failure) => IssueLoadFailure(message: _mapFailureToMessage(failure)),
        (hasdata) => IssueLoadSuccess(gitissue: hasdata));
    print("Here......${getIsue}");
    logger.log('1.2.2');
  }

  String _mapFailureToMessage(Failure failure) {
    switch (failure.runtimeType) {
      case ServerFailure:
        return FailureMessage.server;
      default:
        return FailureMessage.unexpected;
    }
  }
}
