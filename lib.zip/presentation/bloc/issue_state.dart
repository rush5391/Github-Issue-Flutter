import 'package:d_github_issue/domain/entities/issues_data.dart';
import 'package:equatable/equatable.dart';
import 'package:http/http.dart' as http;
import 'dart:developer' as logger;
abstract class IssueState  {

  @override
  List<Object> get props =>[];
}
class IssueInitial extends IssueState{}

class IssueLoading extends IssueState{
}

class IssueLoadSuccess extends IssueState{
  final List<GithubIssue> gitissue;
  IssueLoadSuccess({required this.gitissue});
  @override
  List<Object> get props =>[this.gitissue];
}
class IssueLoadFailure extends IssueState{
  final String message;
  IssueLoadFailure({required this.message});
  @override
  List<Object> get props=>[message];
}