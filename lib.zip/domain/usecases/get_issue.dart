import 'package:d_github_issue/core/error/failures.dart';
import 'package:d_github_issue/core/usecases/usecase.dart';
import 'package:d_github_issue/domain/entities/issues_data.dart';
import 'package:d_github_issue/domain/repositories/issue_repository.dart';
import 'package:dartz/dartz.dart';
import 'package:equatable/equatable.dart';
import 'dart:developer' as logger;
class GetIssue extends UseCase<List<GithubIssue>,IssueParams>{
  final IssueRepository repository;
  GetIssue(this.repository);

  @override
  Future<Either<Failure, List<GithubIssue>>> call(params) async {
    // TODO: implement call
    logger.log('Getting Issue');
   return await repository.getIssue();
  }
}
class IssueParams extends Equatable{
  @override
  // TODO: implement props

  List<Object?> get props =>[];
}