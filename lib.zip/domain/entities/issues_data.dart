import 'dart:convert';

List<GithubIssue> GithubIssueFromJson(String str) => List<GithubIssue>.from(
    json.decode(str).map((x) => GithubIssue.fromJson(x)));

String GithubIssueToJson(List<GithubIssue> data) =>
    json.encode(List<dynamic>.from(data.map((x) => x.toJson())));

class GithubIssue {
  GithubIssue({
    required this.url,
    required this.repositoryUrl,
    required this.labelsUrl,
    required this.commentsUrl,
    required this.eventsUrl,
    required this.htmlUrl,
    required this.id,
    required this.nodeId,
    required this.number,
    required this.title,
    required this.user,
    required this.labels,
    required this.state,
    required this.locked,
    required this.assignee,
    required this.assignees,
    required this.milestone,
    required this.comments,
    required this.createdAt,
    required this.updatedAt,
    required this.closedAt,
    required this.authorAssociation,
    required this.activeLockReason,
    required this.draft,
    required this.pullRequest,
    required this.body,
    required this.reactions,
    required this.timelineUrl,
    required this.performedViaGithubApp,
    required this.stateReason,
  });

  String url;
  String repositoryUrl;
  String labelsUrl;
  String commentsUrl;
  String eventsUrl;
  String htmlUrl;
  var id;
  String nodeId;
  var number;
  String title;
  User user;
  List<Label> labels;
  State? state;
  bool locked;
  dynamic assignee;
  List<dynamic> assignees;
  Milestone? milestone;
  var comments;
  DateTime createdAt;
  DateTime updatedAt;
  dynamic closedAt;
  AuthorAssociation? authorAssociation;
  dynamic activeLockReason;
  bool draft;
  PullRequest? pullRequest;
  String body;
  Reactions reactions;
  String timelineUrl;
  dynamic performedViaGithubApp;
  String stateReason;

  factory GithubIssue.fromJson(Map<String, dynamic> json) => GithubIssue(
        url: json["url"],
        repositoryUrl: json["repository_url"],
        labelsUrl: json["labels_url"],
        commentsUrl: json["comments_url"],
        eventsUrl: json["events_url"],
        htmlUrl: json["html_url"],
        id: json["id"],
        nodeId: json["node_id"],
        number: json["number"],
        title: json["title"],
        user: User.fromJson(json["user"]),
        labels: List<Label>.from(json["labels"].map((x) => Label.fromJson(x))),
        state: stateValues.map[json["state"]],
        locked: json["locked"],
        assignee: json["assignee"],
        assignees: List<dynamic>.from(json["assignees"].map((x) => x)),
        milestone: json["milestone"] == null
            ? null
            : Milestone.fromJson(json["milestone"]),
        comments: json["comments"],
        createdAt: DateTime.parse(json["created_at"]),
        updatedAt: DateTime.parse(json["updated_at"]),
        closedAt: json["closed_at"],
        authorAssociation:
            authorAssociationValues.map[json["author_association"]],
        activeLockReason: json["active_lock_reason"],
        draft: json["draft"] == null ? null : json["draft"],
        pullRequest: json["pull_request"] == null
            ? null
            : PullRequest.fromJson(json["pull_request"]),
        body: json["body"] == null ? null : json["body"],
        reactions: Reactions.fromJson(json["reactions"]),
        timelineUrl: json["timeline_url"],
        performedViaGithubApp: json["performed_via_github_app"],
        stateReason: json["state_reason"] == null ? null : json["state_reason"],
      );

  Map<String, dynamic> toJson() => {
        "url": url,
        "repository_url": repositoryUrl,
        "labels_url": labelsUrl,
        "comments_url": commentsUrl,
        "events_url": eventsUrl,
        "html_url": htmlUrl,
        "id": id,
        "node_id": nodeId,
        "number": number,
        "title": title,
        "user": user.toJson(),
      "labels": List<dynamic>.from(labels.map((x) => x.toJson())),
        "state": stateValues.reverse[state],
        "locked": locked,
        "assignee": assignee,
        "assignees": List<dynamic>.from(assignees.map((x) => x)),
        "milestone": milestone == null ? null : milestone!.toJson(),
        "comments": comments,
        "created_at": createdAt.toIso8601String(),
        "updated_at": updatedAt.toIso8601String(),
        "closed_at": closedAt,
        "author_association":
            authorAssociationValues.reverse[authorAssociation],
        "active_lock_reason": activeLockReason,
        "draft": draft == null ? null : draft,
        "pull_request": pullRequest == null ? null : pullRequest!.toJson(),
        "body": body == null ? null : body,
        "reactions": reactions.toJson(),
        "timeline_url": timelineUrl,
        "performed_via_github_app": performedViaGithubApp,
        "state_reason": stateReason == null ? null : stateReason,
      };
}

enum AuthorAssociation { CONTRIBUTOR, NONE, MEMBER, COLLABORATOR }

final authorAssociationValues = EnumValues({
  "COLLABORATOR": AuthorAssociation.COLLABORATOR,
  "CONTRIBUTOR": AuthorAssociation.CONTRIBUTOR,
  "MEMBER": AuthorAssociation.MEMBER,
  "NONE": AuthorAssociation.NONE
});

class Label {
  Label({
    required this.id,
    required this.nodeId,
    required this.url,
    required this.name,
    required this.color,
    required this.labelDefault,
    required this.description,
  });

  var id;
  NodeId? nodeId;
  String url;
  Name? name;
  Color? color;
  bool labelDefault;
  Description? description;

  factory Label.fromJson(Map<String, dynamic> json) => Label(
        id: json["id"],
        nodeId: nodeIdValues.map[json["node_id"]],
        url: json["url"],
        name: nameValues.map[json["name"]],
        color: colorValues.map[json["color"]],
        labelDefault: json["default"],
        description: descriptionValues.map[json["description"]],
      );

  Map<String, dynamic> toJson() => {
        "id": id,
        "node_id": nodeIdValues.reverse[nodeId],
        "url": url,
        "name": nameValues.reverse[name],
        "color": colorValues.reverse[color],
        "default": labelDefault,
        "description": descriptionValues.reverse[description],
      };
}

enum Color { THE_84_B6_EB, D93_F0_B, EB6420, THE_5319_E7 }

final colorValues = EnumValues({
  "d93f0b": Color.D93_F0_B,
  "eb6420": Color.EB6420,
  "5319e7": Color.THE_5319_E7,
  "84b6eb": Color.THE_84_B6_EB
});

enum Description {
  FEATURE_NOT_A_BUG,
  BUG_IN_EXISTING_CODE,
  MORE_INFORMATION_NEEDED_FROM_REPORTER,
  DOCUMENTATION_TASK
}

final descriptionValues = EnumValues({
  "Bug in existing code": Description.BUG_IN_EXISTING_CODE,
  "Documentation task": Description.DOCUMENTATION_TASK,
  "Feature not a bug": Description.FEATURE_NOT_A_BUG,
  "More information needed from reporter":
      Description.MORE_INFORMATION_NEEDED_FROM_REPORTER
});

enum Name { ENHANCEMENT, BUG, NEEDS_INFO, DOCUMENTATION }

final nameValues = EnumValues({
  "bug": Name.BUG,
  "documentation": Name.DOCUMENTATION,
  "enhancement": Name.ENHANCEMENT,
  "needs info": Name.NEEDS_INFO
});

enum NodeId {
  MDU6_TG_FI_Z_WW5_O_TK4_ODY3,
  MDU6_TG_FI_Z_WW5_O_TK4_ODY1,
  MDU6_TG_FI_Z_WWZ_MDU5_MZ_U0_NZK,
  MDU6_TG_FI_Z_WW5_NZ_A0_MJ_Y0_MQ
}

final nodeIdValues = EnumValues({
  "MDU6TGFiZWw5NzA0MjY0MQ==": NodeId.MDU6_TG_FI_Z_WW5_NZ_A0_MJ_Y0_MQ,
  "MDU6TGFiZWw5OTk4ODY1": NodeId.MDU6_TG_FI_Z_WW5_O_TK4_ODY1,
  "MDU6TGFiZWw5OTk4ODY3": NodeId.MDU6_TG_FI_Z_WW5_O_TK4_ODY3,
  "MDU6TGFiZWwzMDU5MzU0Nzk=": NodeId.MDU6_TG_FI_Z_WWZ_MDU5_MZ_U0_NZK
});

class Milestone {
  Milestone({
    required this.url,
    required this.htmlUrl,
    required this.labelsUrl,
    required this.id,
    required this.nodeId,
    required this.number,
    required this.title,
    required this.description,
    required this.creator,
    required this.openIssues,
    required this.closedIssues,
    required this.state,
    required this.createdAt,
    required this.updatedAt,
    required this.dueOn,
    required this.closedAt,
  });

  String url;
  String htmlUrl;
  String labelsUrl;
  var id;
  String nodeId;
  var number;
  String title;
  String description;
  User creator;
  var openIssues;
  var closedIssues;
  State? state;
  DateTime createdAt;
  DateTime updatedAt;
  DateTime dueOn;
  dynamic closedAt;

  factory Milestone.fromJson(Map<String, dynamic> json) => Milestone(
        url: json["url"],
        htmlUrl: json["html_url"],
        labelsUrl: json["labels_url"],
        id: json["id"],
        nodeId: json["node_id"],
        number: json["number"],
        title: json["title"],
        description: json["description"],
        creator: User.fromJson(json["creator"]),
        openIssues: json["open_issues"],
        closedIssues: json["closed_issues"],
        state: stateValues.map[json["state"]],
        createdAt: DateTime.parse(json["created_at"]),
        updatedAt: DateTime.parse(json["updated_at"]),
        dueOn: DateTime.parse(json["due_on"]),
        closedAt: json["closed_at"],
      );

  Map<String, dynamic> toJson() => {
        "url": url,
        "html_url": htmlUrl,
        "labels_url": labelsUrl,
        "id": id,
        "node_id": nodeId,
        "number": number,
        "title": title,
        "description": description,
        "creator": creator.toJson(),
        "open_issues": openIssues,
        "closed_issues": closedIssues,
        "state": stateValues.reverse[state],
        "created_at": createdAt.toIso8601String(),
        "updated_at": updatedAt.toIso8601String(),
        "due_on": dueOn.toIso8601String(),
        "closed_at": closedAt,
      };
}

class User {
  User({
    required this.login,
    required this.id,
    required this.nodeId,
    required this.avatarUrl,
    required this.gravatarId,
    required this.url,
    required this.htmlUrl,
    required this.followersUrl,
    required this.followingUrl,
    required this.gistsUrl,
    required this.starredUrl,
    required this.subscriptionsUrl,
    required this.organizationsUrl,
    required this.reposUrl,
    required this.eventsUrl,
    required this.receivedEventsUrl,
    required this.type,
    required this.siteAdmin,
  });

  String login;
  var id;
  String nodeId;
  String avatarUrl;
  String gravatarId;
  String url;
  String htmlUrl;
  String followersUrl;
  String followingUrl;
  String gistsUrl;
  String starredUrl;
  String subscriptionsUrl;
  String organizationsUrl;
  String reposUrl;
  String eventsUrl;
  String receivedEventsUrl;
  Type? type;
  bool siteAdmin;

  factory User.fromJson(Map<String, dynamic> json) => User(
        login: json["login"],
        id: json["id"],
        nodeId: json["node_id"],
        avatarUrl: json["avatar_url"],
        gravatarId: json["gravatar_id"],
        url: json["url"],
        htmlUrl: json["html_url"],
        followersUrl: json["followers_url"],
        followingUrl: json["following_url"],
        gistsUrl: json["gists_url"],
        starredUrl: json["starred_url"],
        subscriptionsUrl: json["subscriptions_url"],
        organizationsUrl: json["organizations_url"],
        reposUrl: json["repos_url"],
        eventsUrl: json["events_url"],
        receivedEventsUrl: json["received_events_url"],
        type: typeValues.map[json["type"]],
        siteAdmin: json["site_admin"],
      );

  Map<String, dynamic> toJson() => {
        "login": login,
        "id": id,
        "node_id": nodeId,
        "avatar_url": avatarUrl,
        "gravatar_id": gravatarId,
        "url": url,
        "html_url": htmlUrl,
        "followers_url": followersUrl,
        "following_url": followingUrl,
        "gists_url": gistsUrl,
        "starred_url": starredUrl,
        "subscriptions_url": subscriptionsUrl,
        "organizations_url": organizationsUrl,
        "repos_url": reposUrl,
        "events_url": eventsUrl,
        "received_events_url": receivedEventsUrl,
        "type": typeValues.reverse[type],
        "site_admin": siteAdmin,
      };
}

enum Type { USER, BOT }

final typeValues = EnumValues({"Bot": Type.BOT, "User": Type.USER});

enum State { OPEN }

final stateValues = EnumValues({"open": State.OPEN});

class PullRequest {
  PullRequest({
    required this.url,
    required this.htmlUrl,
    required this.diffUrl,
    required this.patchUrl,
    this.mergedAt,
  });

  String url;
  String htmlUrl;
  String diffUrl;
  String patchUrl;
  dynamic mergedAt;

  factory PullRequest.fromJson(Map<String, dynamic> json) => PullRequest(
        url: json["url"],
        htmlUrl: json["html_url"],
        diffUrl: json["diff_url"],
        patchUrl: json["patch_url"],
        mergedAt: json["merged_at"],
      );

  Map<String, dynamic> toJson() => {
        "url": url,
        "html_url": htmlUrl,
        "diff_url": diffUrl,
        "patch_url": patchUrl,
        "merged_at": mergedAt,
      };
}

class Reactions {
  Reactions({
    required this.url,
    required this.totalCount,
    required this.the1,
    required this.reactions1,
    required this.laugh,
    required this.hooray,
    required this.confused,
    required this.heart,
    required this.rocket,
    required this.eyes,
  });

  String url;
  var totalCount;
  var the1;
  var reactions1;
  var laugh;
  var hooray;
  var confused;
  var heart;
  var rocket;
  var eyes;

  factory Reactions.fromJson(Map<String, dynamic> json) => Reactions(
        url: json["url"],
        totalCount: json["total_count"],
        the1: json["+1"],
        reactions1: json["-1"],
        laugh: json["laugh"],
        hooray: json["hooray"],
        confused: json["confused"],
        heart: json["heart"],
        rocket: json["rocket"],
        eyes: json["eyes"],
      );

  Map<String, dynamic> toJson() => {
        "url": url,
        "total_count": totalCount,
        "+1": the1,
        "-1": reactions1,
        "laugh": laugh,
        "hooray": hooray,
        "confused": confused,
        "heart": heart,
        "rocket": rocket,
        "eyes": eyes,
      };
}

class EnumValues<T> {
  Map<String, T> map;
  late Map<T, String> reverseMap;

  EnumValues(this.map);

  Map<T, String> get reverse {
    if (reverseMap == null) {
      reverseMap = map.map((k, v) => new MapEntry(v, k));
    }
    return reverseMap;
  }
}

List<Map<String, dynamic>> issueListoJsonList(List<GithubIssue> gitIssues) {
  List<Map<String, dynamic>> issueJson = [];
  gitIssues.forEach((issues) {
    issueJson.add(issues.toJson());
  });
  return issueJson;
}

List<GithubIssue> issueModelListFromJsonList(List<dynamic> jsonList) {
  List<GithubIssue> issues = [];
  if (jsonList.isEmpty) return [];
  jsonList.forEach((element) {
    final data = GithubIssue.fromJson(element);
    issues.add(data);
  });
  return issues;
}
