import 'dart:developer' as logger;
import 'package:d_github_issue/domain/entities/issues_data.dart';
import 'package:d_github_issue/presentation/bloc/issue_bloc.dart';
import 'package:d_github_issue/presentation/bloc/issue_state.dart';
import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';

class IssuePages extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text(
          "Github Mobile View",
          style: TextStyle(color: Colors.white),
        ),
      ),
      body: Column(
        children: [

          SizedBox(height: 10,),
          Row(
            children: [
              Container(
                  height: 20,
                  margin: EdgeInsets.all(2),
                  color: Colors.grey[350],
                  child: Text("Code")),
              Container(
                height: 20,
                  margin: EdgeInsets.all(2),
                  color: Colors.grey[350],
                  child: Text("Issue 202")),
              Container(
                  height: 20,
                  margin: EdgeInsets.all(2),
                  color: Colors.grey[350],
                  child: Text("Pull Request")),
              Container(
                  height: 20,
                  margin: EdgeInsets.all(2),
                  color: Colors.grey[350],
                  child: Text("Actions")),
              Container(
                  height: 20,
                  margin: EdgeInsets.all(2),
                  color: Colors.grey[350],
                  child: Text("Security")),
              Container(
                  height: 20,
                  margin: EdgeInsets.all(2),
                  color: Colors.grey[350],
                  child: Text("Insights"))
            ],
          ),
          Container(
            width: 250,
            height: 50,
            decoration: BoxDecoration(
              borderRadius: BorderRadius.circular(10),
              color: Colors.white,
              boxShadow: [
                BoxShadow(color: Colors.green, spreadRadius: 1),
              ],
            ),
            child: Column(
              children: [
                Center(child: Text("OkHttp 5 Blockers"))
              ],
            ),
          ),
          SizedBox(height: 20,),
          Row(
            children: [
              Container(
                width: 100,
                height: 30,
                margin: EdgeInsets.all(5),
                decoration: BoxDecoration(
                  borderRadius: BorderRadius.circular(10),
                  color: Colors.white,
                  boxShadow: [
                    BoxShadow(color: Colors.green, spreadRadius: 1),
                  ],
                ),
                child: Row(
                  children: [
                    Container(child: Icon(Icons.search)),
                  ],
                ),
              ),
              Container(
                width: 100,
                height: 30,
                margin: EdgeInsets.all(5),
                decoration: BoxDecoration(
                  borderRadius: BorderRadius.circular(10),
                  color: Colors.white,
                  boxShadow: [
                    BoxShadow(color: Colors.green, spreadRadius: 1),
                  ],
                ),
                child: Row(
                  children: [
                    Container(child: Icon(Icons.label)),
                    Text("Labels 19")
                  ],
                ),
              ),
              Container(
                width: 100,
                height: 30,
                margin: EdgeInsets.all(5),
                decoration: BoxDecoration(
                  borderRadius: BorderRadius.circular(10),
                  color: Colors.green,
                  boxShadow: [
                    BoxShadow(color: Colors.green, spreadRadius: 1),
                  ],
                ),
                child: Center(child: Text("New Issue",style: TextStyle(color: Colors.white),)),
              ),
            ],
          ),
          BlocBuilder<IssueBloc, IssueState>(builder: (context, Istate) {
            if (Istate is IssueInitial) {
              logger.log('1.1');
              _initIssue(context);
              return Center(child: CircularProgressIndicator());
            } else if (Istate is IssueLoading) {
              logger.log('1.2');
              return Center(
                child: Text("Loading..."),
              );
            } else if (Istate is IssueLoadSuccess) {
              logger.log('1.3');
              return _loadedSuccess(context, Istate.gitissue);
            } else if (Istate is IssueLoadFailure) {
              logger.log('1.4');
              return _IssueLoadFailure(context, Istate.message);
            } else
              return Container(
                child: Text("No Data Found"),
              );
          }),
        ],
      ),
    );
  }

  void _initIssue(BuildContext context) {
    logger.log('3');
    BlocProvider.of<IssueBloc>(context).getI();
  }

  Widget _loadedSuccess(BuildContext context, List<GithubIssue> gitIssue) {
    logger.log('1.5');
    BlocProvider.of<IssueBloc>(context).getI();
    return Container(
      child: Column(
        children: [

          gitIssue.isEmpty
              ? CircularProgressIndicator()
              : ListView.builder(
                  itemCount: gitIssue.length,
                  itemBuilder: (context, index) {
                    return Container(child: Text(gitIssue[index].url));
                  }),
        ],
      ),
    );
  }

  Widget _IssueLoadFailure(BuildContext context, String message) {
    logger.log('5');
    showDialog(
      context: context,
      builder: (context) => AlertDialog(
        title: Text('Error'),
        content: Text(message),
      ),
    );
    return CircularProgressIndicator();
  }
}
