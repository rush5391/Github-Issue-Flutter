import 'package:data_connection_checker/data_connection_checker.dart';
import 'package:http/http.dart' as http;
import 'package:d_github_issue/core/network/network_info.dart';
import 'package:d_github_issue/data/datasources/issue/issue_local_data_sources.dart';
import 'package:d_github_issue/data/datasources/issue/issue_remote_data_sources.dart';
import 'package:d_github_issue/data/repositories/issue_repository_impl.dart';
import 'package:d_github_issue/domain/repositories/issue_repository.dart';
import 'package:d_github_issue/domain/usecases/get_issue.dart';
import 'package:d_github_issue/presentation/bloc/issue_bloc.dart';
import 'package:get_it/get_it.dart';
import 'package:shared_preferences/shared_preferences.dart';

final sl = GetIt.instance;

Future<void> init() async {
  //!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!
  //!     GitHub Issue Api
  //!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!
  sl.registerLazySingleton<IssueRepository>(
        () => IssueRpositoryImpl(
      networkInfo: sl(),
      localDataSources: sl(),
      remoteDataSource: sl(),
    ),
  );
  // DataSources
  sl.registerLazySingleton<IssueRemoteDataSource>(
        () => IssueRemoteDataSourceImpl(client: sl()),
  );
  sl.registerLazySingleton<IssueLocalDataSources>(
        () => IssueLocalDataSourcesImpl(sharedPreferences: sl()),
  );
  //!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!
  //!     GitHub Issue
  //!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!
  // Business Logic
  sl.registerFactory(() => IssueBloc(githubIssue: sl()));
  // UseCases
  sl.registerLazySingleton(() => GetIssue(sl()));
  //!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!
  //!     CORE
  //!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!
  sl.registerLazySingleton<NetworkInfo>(() => NetworkInfoImpl(sl()));
  //!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!
  //!     EXTERNAL
  //!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!
  // shared preferences
  final sharedPreferences = await SharedPreferences.getInstance();
  sl.registerLazySingleton(() => sharedPreferences);
  // http
  sl.registerLazySingleton(() => http.Client());
  // connection checker
  sl.registerLazySingleton(() => DataConnectionChecker());
}
