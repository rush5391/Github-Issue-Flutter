import 'package:d_github_issue/core/error/failures.dart';
import 'package:d_github_issue/domain/entities/issues_data.dart';
import 'package:dartz/dartz.dart';

abstract class IssueRepository{
  Future<Either<Failure,List<GithubIssue>>> getIssue();
}