import 'dart:convert';
import 'package:d_github_issue/core/api/issue_api.dart';
import 'package:d_github_issue/core/error/exception.dart';
import 'package:d_github_issue/domain/entities/issues_data.dart';
import 'package:http/http.dart' as http;
import 'dart:developer' as logger;

abstract class IssueRemoteDataSource {
  Future<List<GithubIssue>> getIssue();
}

class IssueRemoteDataSourceImpl implements IssueRemoteDataSource {
  final http.Client client;

  IssueRemoteDataSourceImpl({required this.client});

  @override
  Future<List<GithubIssue>> getIssue() async {

    String uri = "https://api.github.com/repos/square/okhttp/issues";
    final response = await client.get(Uri.parse(uri));
    var extractedData = json.decode(response.body) as List;
    List<GithubIssue> _listIssue = [];
    if (response.statusCode == 200) {
      extractedData.forEach((element) {
        _listIssue.add(GithubIssue(
            url: element['url'] == null ? "urls" : element['url'],
            repositoryUrl: element['repositoryUrl'] == null
                ? "repository"
                : element['repositoryUrl'],
            labelsUrl:
            element['labelsUrl'] == null ? "lblurl" : element['labelsUrl'],
            commentsUrl:
            element['commentsUrl'] == null ? "comurl" : element['commentsUrl'],
            eventsUrl:
            element['eventsUrl'] == null ? "events" : element['eventsUrl'],
            htmlUrl: element['htmlUrl'] == null ? "htmlurl" : element['htmlUrl'],
            id: element['id'] == null ? "id" : element['id'],
            nodeId: element['nodeId'] == null ? "nodeid" : element['nodeId'],
            number: element['number'] == null ? "numbers" : element['number'],
            title: element['title'] == null ? "titles" : element['title'],
            user:
            User.fromJson(element['user'] == null ? element['user'].toString().isNotEmpty : element['user']),
            labels: List<Label>.from(
                element['labels'].map((x) => Label.fromJson(x).toJson().isNotEmpty)),
            state: stateValues.map[element["state"]],
            locked: element['locked'] == null ? "locked" : element['locked'],
            assignee: element['assignee'] == null
                ? "assign"
                : element['assignee'],
            assignees:
            element['assignees'] == null ? "assignes" : element['assignees'],
            milestone: Milestone.fromJson(
                element['milestone'] == null
                    ? element['milestone'].toString().isNotEmpty
                    : element['milestone']),
            comments: element['comments'] == null
                ? "commenta"
                : element['comments'],
            createdAt:
            element['createdAt'] == null ? "createdat" : element['createdAt'],
            updatedAt:
            element['updatedAt'] == null ? "updatedat" : element['updatedAt'],
            closedAt: element['closedAt'] == null
                ? "closedat"
                : element['closedAt'],
            authorAssociation: element['authorAssociation'] == null
                ? element['authorAssociation'].toString().isNotEmpty
                : element['authorAssociation'],
            activeLockReason: element['activeLockReason'] == null
                ? "activelok"
                : element['activeLockReason'],
            draft: element['draft'] == null ? "draft" : element['draft'],
            pullRequest:
            element['pullRequest'] == null ? "pullreq" : element['pullRequest'],
            body: element['body'] == null ? "body" : element['body'],
            reactions: Reactions.fromJson(
                element['reactions'] == null
                    ? element['reactions'].toString().isNotEmpty
                    : element['reactions']),
            timelineUrl:
            element['timelineUrl'] == null ? "time" : element['timelineUrl'],
            performedViaGithubApp: element['performedViaGithubApp'] == null
                ? "performed"
                : element['performedViaGithubApp'],
            stateReason: element['stateReason'] == null
                ? "statereason"
                : element['stateReason']));
      });
      logger.log('issueRemoteDataSource');
      return issueModelListFromJsonList(_listIssue);
    } else {
      throw ServerException();
    }
  }
}
